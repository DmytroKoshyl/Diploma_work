

import time
import cv2
from ultralytics import YOLO


MODEL_PATH   = "weights/best.pt"
VIDEO_PATH   = "data/test_video.mp4"
CONFIDENCE   = 0.25

def main():

    model = YOLO(MODEL_PATH)

    cap = cv2.VideoCapture(VIDEO_PATH)
    if not cap.isOpened():
        print(f"Cannot open video: {VIDEO_PATH}")
        return

    total_frames      = 0
    frames_with_obj   = 0
    total_detections  = 0
    start_time        = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        total_frames += 1

        results = model.predict(source=[frame], conf=CONFIDENCE, save=False)
        dets    = results[0].boxes
        count   = len(dets)
        total_detections += count
        if count:
            frames_with_obj += 1


        for box, conf, cls in zip(dets.xyxy.cpu().numpy(),
                                  dets.conf.cpu().numpy(),
                                  dets.cls.cpu().numpy().astype(int)):
            x1, y1, x2, y2 = map(int, box)
            label = f"{results[0].names[cls]} {conf:.2f}"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0,0,255), 2)
            cv2.putText(frame, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)


        cv2.imshow("Disease Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break


    duration     = time.time() - start_time
    avg_time     = duration / total_frames if total_frames else 0
    fps          = total_frames / duration if duration > 0 else 0
    pct_frames   = frames_with_obj / total_frames * 100 if total_frames else 0
    avg_per_frame= total_detections / total_frames if total_frames else 0

    print("\n=== СТАТИСТИКА ПО ВІДЕО ===")
    print(f"Відео                  : {VIDEO_PATH}")
    print(f"Модель                 : {MODEL_PATH}")
    print(f"Кадрів оброблено       : {total_frames}")
    print(f"Кадрів з виявленнями   : {frames_with_obj} ({pct_frames:.1f}%)")
    print(f"Загалом детекцій       : {total_detections}")
    print(f"Середньо детекцій/кадр: {avg_per_frame:.2f}")
    print(f"Загальний час (сек)    : {duration:.2f}")
    print(f"Сек/кадр               : {avg_time:.4f}")
    print(f"Середній FPS           : {fps:.2f}")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
