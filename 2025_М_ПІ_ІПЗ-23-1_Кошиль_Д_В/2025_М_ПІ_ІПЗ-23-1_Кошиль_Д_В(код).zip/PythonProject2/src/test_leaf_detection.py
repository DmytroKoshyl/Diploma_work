import cv2
from ultralytics import YOLO

VIDEO_PATH = "data/test_video.mp4"
MODEL_PATH = "weights/plant_leaf_foduu.pt"
CONFIDENCE = 0.25

def main():
    model = YOLO(MODEL_PATH)
    cap = cv2.VideoCapture(VIDEO_PATH)
    if not cap.isOpened():
        print("Cannot open video:", VIDEO_PATH)
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break


        results = model.predict(source=[frame], conf=CONFIDENCE, save=False)
        boxes = results[0].boxes.xyxy.cpu().numpy()
        scores = results[0].boxes.conf.cpu().numpy()
        classes = results[0].boxes.cls.cpu().numpy().astype(int)


        for (x1, y1, x2, y2), score, cls in zip(boxes, scores, classes):
            label = f"{results[0].names[cls]} {score:.2f}"
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0,255,0), 2)
            cv2.putText(frame, label, (int(x1), int(y1)-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

        cv2.imshow("Leaf Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
