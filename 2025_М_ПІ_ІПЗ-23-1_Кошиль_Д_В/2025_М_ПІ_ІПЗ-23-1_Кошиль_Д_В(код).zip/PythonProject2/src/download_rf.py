from roboflow import Roboflow

rf = Roboflow("ROBOFLOW_API_KEY","XMnPlQYV6ZkcyGkRGcdp")
project = rf.workspace().project("plants-diseases-detection-and-classification")
model   = project.version(1).model
model.download("weights/plant_diseases_rf.pt")
