
import time
from ultralytics import YOLO

MODEL_PATH = "weights/plant_leaf_hf.pt"
VIDEO_PATH = "data/test_video.mp4"
CONFIDENCE = 0.25

def run_video_test(model_path, video_path):
    model = YOLO(model_path)
    total, with_obj = 0, 0
    start = time.time()
    for result in model.predict(source=video_path, conf=CONFIDENCE, stream=True):
        total += 1
        if len(result.boxes): with_obj += 1
        print(f"Frame {total:3d}: {len(result.boxes)} detections")
    dur = time.time() - start
    print(f"\nProcessed: {total} frames, {with_obj} with detections ({with_obj/total*100:.1f}%)")
    print(f"Time: {dur:.2f}s, ~{total/dur:.2f} FPS")

if __name__ == "__main__":
    run_video_test(MODEL_PATH, VIDEO_PATH)
