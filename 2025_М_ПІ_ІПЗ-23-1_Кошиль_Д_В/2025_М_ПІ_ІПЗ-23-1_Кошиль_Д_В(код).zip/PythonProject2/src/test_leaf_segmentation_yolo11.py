

import cv2
import numpy as np
import time
from ultralytics import YOLO

VIDEO_PATH = "data/test_video.mp4"
MODEL_PATH = "weights/yolo11n-seg.pt"
CONFIDENCE = 0.25

def main():

    model = YOLO(MODEL_PATH)
    cap   = cv2.VideoCapture(VIDEO_PATH)
    if not cap.isOpened():
        print(f"Cannot open video: {VIDEO_PATH}")
        return

    total_frames       = 0
    frames_with_apple  = 0
    total_inf_time     = 0.0
    start_total_time   = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        total_frames += 1

        t0 = time.time()
        results = model.predict(
            source=[frame],
            task="segment",
            conf=CONFIDENCE,
            save=False
        )
        inf_time = time.time() - t0
        total_inf_time += inf_time

        res0   = results[0]
        masks  = res0.masks
        boxes  = res0.boxes
        names  = res0.names

        cls_ids     = boxes.cls.cpu().numpy().astype(int)
        apple_count = sum(1 for cid in cls_ids if names[cid].lower().startswith("apple"))
        if apple_count:
            frames_with_apple += 1
            print(f"{total_frames-1}: {frame.shape[0]}x{frame.shape[1]} {apple_count} apples, {inf_time*1000:.1f}ms")
        else:
            print(f"{total_frames-1}: {frame.shape[0]}x{frame.shape[1]} (no apples), {inf_time*1000:.1f}ms")

        canvas = frame.copy()
        if masks and masks.xy:
            for seg, cid in zip(masks.xy, cls_ids):
                if not names[cid].lower().startswith("apple"):
                    continue
                pts = seg.astype(int).reshape(-1, 1, 2)
                color = (0, 255, 0)
                cv2.drawContours(canvas, [pts], -1, color, 2)
                M = cv2.moments(pts)
                if M["m00"] > 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    cv2.putText(canvas, names[cid], (cx, cy),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        cv2.imshow("Leaf Segmentation (YOLO11-seg)", canvas)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

    total_time  = time.time() - start_total_time
    pct_frames  = (frames_with_apple / total_frames * 100) if total_frames else 0.0
    percent_inf = (total_inf_time / total_time * 100) if total_time else 0.0

    print("\n=== СТАТИСТИКА ЧАСУ ===")
    print(f"Кадрів оброблено            : {total_frames}")
    print(f"Кадрів із яблуками          : {frames_with_apple} ({pct_frames:.1f}% від усіх кадрів)")
    print(f"Загальний час виконання (с)  : {total_time:.2f}")
    print(f"Загальний час інференсу (с)  : {total_inf_time:.2f}")
    print(f"Відсоток часу інференсу      : {percent_inf:.2f}%")

if __name__ == "__main__":
    main()
