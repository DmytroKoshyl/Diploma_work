from ultralytics import YOLO
import cv2

model = YOLO("weights/plant_leaf_hf.pt")
VIDEO_PATH = "data/test_video.mp4"


CONFIDENCE = 0.15

NMS_IOU    = 0.3

cap = cv2.VideoCapture(VIDEO_PATH)
while True:
    ret, frame = cap.read()
    if not ret: break


    results = model.predict(source=[frame], conf=CONFIDENCE, iou=NMS_IOU, save=False)
    for box, conf, cls in zip(results[0].boxes.xyxy.cpu(),
                               results[0].boxes.conf.cpu(),
                               results[0].boxes.cls.cpu().int()):
        x1,y1,x2,y2 = map(int, box)
        label = f"{results[0].names[int(cls)]} {conf:.2f}"
        cv2.rectangle(frame, (x1,y1),(x2,y2), (0,0,255), 2)
        cv2.putText(frame, label, (x1,y1-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255),1)

    cv2.imshow("Disease (tuned)", frame)
    if cv2.waitKey(1)&0xFF==ord("q"): break

cap.release()
cv2.destroyAllWindows()
