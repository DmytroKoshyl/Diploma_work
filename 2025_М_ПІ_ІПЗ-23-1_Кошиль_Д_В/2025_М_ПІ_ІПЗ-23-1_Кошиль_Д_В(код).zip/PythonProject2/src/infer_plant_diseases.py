from inference_sdk import InferenceHTTPClient


API_KEY = "XMnPlQYV6ZkcyGkRGcdp"


client = InferenceHTTPClient(
    api_url="https://serverless.roboflow.com",
    api_key=API_KEY
)


model_id = "plants-diseases-detection-and-classification/12"


result = client.infer("data/test_video.mp4", model_id=model_id)


for pred in result["predictions"]:
    print(f"{pred['class']}: {pred['confidence']:.2f}  bbox={pred['bbox']}")
